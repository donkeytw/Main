function validate() {

    let error_message = "";

    // validate pizza size
    let size = document.getElementsByName("pizza_size");
    let checked = false;
    for (let i = 0; i < size.length; i++) {
        if (size[i].checked) {
            checked = true;
        }
    }
    if (!checked) {
        error_message = error_message.concat("A size of pizza must be selected.\n");
    }

    //validate customer info by checking for text in the info field
    let customer_info = document.getElementById("customer_info")
    if (customer_info.value === "") {
        error_message = error_message.concat("Customer info field must be filled.\n");
    }

    //validate toppings
    let toppings = document.querySelectorAll(".toppings")
    let toppings_count = 0;
    for (let i = 0; i < toppings.length; i++) {
        if (toppings[i].checked) {
            toppings_count++;
        }
    }
    if (toppings_count != 2) {
        error_message = error_message.concat("Two toppings must be selected: " + toppings_count + " selected" );
    }

    if (error_message != "") {
        alert(error_message);
    }
    return error_message === "";
}
