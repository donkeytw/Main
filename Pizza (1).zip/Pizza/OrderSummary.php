<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Confirmation page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
        $size_prices = array(
            '12' => 20.99,
            '14' => 35.99,
            '16' => 55.99
        );

        $topping_prices = array(
            'Pepperoni' => 2.99,
            'Sausage' => 5.99,
            'Bell Peppers' => 1.99,
            'Mushrooms' => 1.99,
            'Red Onion' => 1.99,
        );

        if (validate_POST()) {

            $pizza_size = $_POST["pizza_size"];
            $customer_info = $_POST["customer_info"];
            $topping_one = $_POST["pizza_toppings"][0];
            $topping_two = $_POST["pizza_toppings"][1];
            $comment = $_POST["comments"] ?? "";

            $total = calculate_total();

            echo <<<HTML
            <section>
                <h4>Pizza order:</h4>
                <table>
                    <thead>
                        <tr>
                            <th></th>
                            <th>Item</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>Size</th>
                            <td>{$pizza_size}" Pizza</td>
                            <td class="number">${size_prices[$pizza_size]}</td>
                        </tr>
                        <tr>
                            <th>Topping</th>
                            <td>{$topping_one}</td>
                            <td class="number">{$topping_prices[$topping_one]}</td>
                        </tr>
                        <tr>
                            <th>Topping</th>
                            <td>{$topping_two}</td>
                            <td class="number">{$topping_prices[$topping_two]}</td>
                        </tr>
                        <tr>
                            <th>Total</th>
                            <td colspan="2" class="number">{$total}</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                           <th>Customer Info:</th>
                           <td colspan="2">{$customer_info}</td>                             
                        </tr>
                        <tr>
                            <th>Extra Instructions:</th>
                            <td colspan="2">{$comment}</td>
                        </tr>
                    </tfoot>
                </table>
                <form action="vardump.php" method="POST">
                    <input type="hidden" name="topping_one" value="{$topping_one}">
                    <input type="hidden" name="topping_two" value="{$topping_two}">
                    <input type="hidden" name="pizza_size" value="{$pizza_size}">
                    <input type="hidden" name="customer_info" value="{$customer_info}">
                    <input type="hidden" name="comments" value="{$comment}">
                    <input type="hidden" name="key" value="12345">
                    <input type="button" onclick="history.back()" value="Back">
                    <input type="submit" value="Submit">
                </form>
            </section>
HTML;
        } else {
            echo <<<HTML
            <p>Invalid form submission. <a href="pizza.html">Click here to go Back</a></p>
HTML;

        }

    // validate POST array contents
    function validate_POST() : bool {
        return isset($_POST["pizza_size"])
            && isset($_POST["customer_info"])
            && isset($_POST["pizza_toppings"])
            && count($_POST["pizza_toppings"]) == 2;
    }

    function calculate_total() : float {
        $total = 0;

        global $size_prices;
        global $topping_prices;

        $total += $size_prices[$_POST["pizza_size"]];
        $total += $topping_prices[$_POST["pizza_toppings"][0]];
        $total += $topping_prices[$_POST["pizza_toppings"][1]];

        return $total;
    }

    ?>
    </body>
</html>