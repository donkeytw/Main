<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>var dump</title>
    </head>
    <body>
        <p>Sorry, I don't do anything yet!</p>

        <?php
            echo '<p>' . var_dump($_POST) . '</p>';
        ?>

        <p><a href="pizza.html">Go back to the pizza form.</a></p>
    </body>
</html>
